# Basic-CRUD-PHP-MySQL
Here is a web view running on localhost.

![vid2](https://user-images.githubusercontent.com/66185022/105703821-c6a63f00-5f48-11eb-81d2-eee4b805243b.gif)

How to run this project?
1. Install XAMPP on your laptop then turn on Apache and MySQL.
2. Download or clone this repository and move the folder to C:/xampp/htdocs.
3. Now, write localhost/phpmyadmin into your browser, after that import the database.
4. Finally, access the web at localhost/belajar-crud/index.php in your browser.
